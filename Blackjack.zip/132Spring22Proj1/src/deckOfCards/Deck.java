package deckOfCards;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

public class Deck {
	ArrayList<Card> deck = new ArrayList();
	public Deck(){
		int count;
		for(int i =0;i<4;i++) {
			Suit curSuit= Suit.values()[i];
			for(int j=0;j<13;j++) {
				Rank curRank = Rank.values()[j];
				Card currCard=new Card(curRank,curSuit);
				deck.add(currCard);
			}
			
		}
		
	
		
	}
	public void shuffle(Random randomNumberGenerator) {
		Collections.shuffle(deck,randomNumberGenerator);
	}
	public Card dealOneCard() {
		Card remCard=deck.get(0);
		deck.remove(0);
		return remCard;
	}

	
}
