package blackjack;

import java.util.ArrayList;
import java.util.Random;

import deckOfCards.*;

public class BlackjackModel {
	private ArrayList<Card>dealerCards;
	private ArrayList<Card> playerCards;
	private Deck deck;
	
	
	public ArrayList<Card> getDealerCards() {
		ArrayList<Card> playerCards2;
		playerCards2 = new ArrayList<Card>();
		for(int i =0;i<dealerCards.size();i++) {
			playerCards2.add(dealerCards.get(i));
		}
		return playerCards2;
	}

	public ArrayList<Card> getPlayerCards() {
		ArrayList<Card> playerCards2;
		playerCards2 = new ArrayList<Card>();
		for(int i =0;i<playerCards.size();i++) {
			playerCards2.add(playerCards.get(i));
		}
		return playerCards2;
	}

	public void setPlayerCards(ArrayList<Card> playerCards) {
		this.playerCards = playerCards;
	}

	

	public void setDealerCards(ArrayList<Card> dealerCards) {
		this.dealerCards = dealerCards;
	}
	
	public void createAndShuffleDeck(Random random) {
		deck= new Deck();
		deck.shuffle(random);
	}
	public void initialDealerCards() {
		dealerCards = new ArrayList<Card>();
		dealerCards.add(deck.dealOneCard());
		dealerCards.add(deck.dealOneCard());
		
	}
	public void initialPlayerCards() {
		playerCards = new ArrayList<Card>();
		playerCards.add(deck.dealOneCard());
		playerCards.add(deck.dealOneCard());
		
	}
	public void playerTakeCard() {
		playerCards.add(deck.dealOneCard());
	}
	public void dealerTakeCard() {
		dealerCards.add(deck.dealOneCard());
	}
	public static ArrayList<Integer> possibleHandValues(ArrayList<Card> hand){
		int stanTotal=0;
		ArrayList<Card>aces= new ArrayList();
		ArrayList<Card>stan= new ArrayList();
		ArrayList<Integer>ans= new ArrayList();
		for(int i=0;i<hand.size();i++) {
			if(hand.get(i).getRank()==Rank.ACE) {
				aces.add(hand.get(i));
			}
			else {
				stan.add(hand.get(i));
			}
		}
		for(int j=0;j<stan.size();j++) {
			stanTotal+=stan.get(j).getRank().getValue();
		}
		
		
		
		if(aces.size()==0) {
			ans.add(stanTotal);
			
			
		}
		
		else {
			int teptotal=stanTotal+11;
			int teptotal2= stanTotal+1;
			int teptotal3=0;
			int teptotal4=0;
			if(teptotal<=21) {
				ans.add(teptotal);
			}
			
			if(teptotal>21&&teptotal2>21) {
				ans.add(teptotal2);
			}

			if(teptotal2<=21) {
				ans.add(teptotal2);
			}
			
			for(int x=1;x<aces.size();x++) {
				ArrayList newAns = new ArrayList();
				for(int j=0;j<ans.size();j++) {
					teptotal3=ans.get(j)+11;
					teptotal4=ans.get(j)+1;
					if(teptotal3<=21&&!ans.contains(teptotal3)) {
						
						newAns.add(teptotal3);
					}
					if(teptotal4<=21) {
						newAns.add(teptotal4);
					}
				}
				ans=newAns;
				
			}
				
				
			
			
		}
		return ans;	

	}
	public static HandAssessment assessHand(ArrayList<Card> hand) {
		if(hand.size()<2) {
			return HandAssessment.INSUFFICIENT_CARDS;
		}
		if(hand.size()==2) {
			if(possibleHandValues(hand).contains(21)) {
				return HandAssessment.NATURAL_BLACKJACK;
			}
		}
		if(possibleHandValues(hand).size()==0||biggest(possibleHandValues(hand))>21) {
			
			return HandAssessment.BUST;
			
		}
			return HandAssessment.NORMAL;
		
	}
	
	public static int biggest(ArrayList<Integer>values) {
		int ans=0;
		for(int i =0;i<values.size();i++) {
			if(values.get(i)>ans) {
				ans=values.get(i);
			}
		}
		return ans;
		
	}
	public boolean dealerShouldTakeCard() {
		ArrayList<Integer> dealerVal = possibleHandValues(dealerCards);
		int dealbig = biggest(dealerVal);
		if(dealbig<16) {
			return true;
		}
		else if(dealbig>18) {
			return false;
		}
		else if(dealerVal.contains(7)&&dealerVal.contains(17)) {
			return true;
		}
		else {
			return false;
			
		}
	}
	public GameResult gameAssessment() {
		HandAssessment playres=assessHand(playerCards);
		HandAssessment dealres=assessHand(dealerCards);
		ArrayList<Integer> playerVal = possibleHandValues(playerCards);
		ArrayList<Integer> dealerVal = possibleHandValues(dealerCards);
		int playbig=biggest(playerVal);
		int dealbig = biggest(dealerVal);
		
		
		
	
		if(playres==HandAssessment.NATURAL_BLACKJACK && dealres!=HandAssessment.NATURAL_BLACKJACK) {
			return GameResult.NATURAL_BLACKJACK;
		}
		else if(playres==HandAssessment.NATURAL_BLACKJACK && dealres==HandAssessment.NATURAL_BLACKJACK){
			return GameResult.PUSH;
		}
		else {
			if(playres==HandAssessment.BUST) {
				return GameResult.PLAYER_LOST;
			}
			else if(dealres==HandAssessment.BUST) {
				return GameResult.PLAYER_WON;
			}
			else {
				if(playbig>dealbig) {
					return GameResult.PLAYER_WON;
					
				}
				else if(playbig<dealbig) {
					return GameResult.PLAYER_LOST;
				}
				else {
					return GameResult.PUSH;
				}
			}
			
		}
		
	
	}
	

}
